const express = require('express');
const cors = require('cors');
const connection = require('./db');
const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

// Get all students
app.get('/students', (req, res) => {
  connection.query('SELECT * FROM students', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Get a student by ID
app.get('/students/:id', (req, res) => {
  const { id } = req.params;
  connection.query('SELECT * FROM students WHERE id = ?', [id], (err, result) => {
    if (err) throw err;
    res.json(result[0]);
  });
});

// Add a new student
app.post('/students', (req, res) => {
  const { name, email, course, address, mobile, dob } = req.body;
  connection.query(
    'INSERT INTO students (name, email, course, address, mobile, dob) VALUES (?, ?, ?, ?, ?, ?)',
    [name, email, course, address, mobile, dob],
    (err, result) => {
      if (err) throw err;
      res.json({ message: "Student added successfully!" });
    }
  );
});

// Update student
app.put('/students/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, course, address, mobile, dob } = req.body;
  connection.query(
    'UPDATE students SET name = ?, email = ?, course = ?, address = ?, mobile = ?, dob = ? WHERE id = ?',
    [name, email, course, address, mobile, dob, id],
    (err, result) => {
      if (err) throw err;
      res.json({ message: "Student updated successfully!" });
    }
  );
});

// Delete student
app.delete('/students/:id', (req, res) => {
  const { id } = req.params;
  connection.query('DELETE FROM students WHERE id = ?', [id], (err, result) => {
    if (err) throw err;
    res.json({ message: "Student deleted successfully!" });
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
