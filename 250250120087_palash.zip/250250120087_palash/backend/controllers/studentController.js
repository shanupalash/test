const db = require('../db');

// Create student
exports.createStudent = (req, res) => {
  const { name, email, course, address, mobile, dob } = req.body;
  if (!name || !email || !course || !address || !mobile || !dob) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  const sql = 'INSERT INTO students (name, email, course, address, mobile, dob) VALUES (?, ?, ?, ?, ?, ?)';
  db.query(sql, [name, email, course, address, mobile, dob], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ message: 'Student added successfully', id: result.insertId });
  });
};

// Get all students
exports.getAllStudents = (req, res) => {
  const sql = 'SELECT * FROM students';
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json(results);
  });
};

// Update student
exports.updateStudent = (req, res) => {
  const { id } = req.params;
  const { name, email, course, address, mobile, dob } = req.body;
  const sql = 'UPDATE students SET name = ?, email = ?, course = ?, address = ?, mobile = ?, dob = ? WHERE id = ?';
  db.query(sql, [name, email, course, address, mobile, dob, id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json({ message: 'Student updated successfully' });
  });
};

// Delete student
exports.deleteStudent = (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM students WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json({ message: 'Student deleted successfully' });
  });
};
