import axios from 'axios';

const API_URL = "http://localhost:5000";

export const getStudents = async () => {
  const res = await axios.get(`${API_URL}/students`);
  return res.data;
};

export const getStudentById = async (id) => {
  const res = await axios.get(`${API_URL}/students/${id}`);
  return res.data;
};

export const addStudent = async (student) => {
  await axios.post(`${API_URL}/students`, student);
};

export const updateStudent = async (id, student) => {
  await axios.put(`${API_URL}/students/${id}`, student);
};

export const deleteStudent = async (id) => {
  await axios.delete(`${API_URL}/students/${id}`);
};
