import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getStudentById, updateStudent } from '../services/studentService';

function EditStudent() {
  const [student, setStudent] = useState({
    name: '',
    email: '',
    course: '',
    address: '',
    mobile: '',
    dob: ''
  });

  const [errors, setErrors] = useState({});
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    loadStudent();
  }, []);

  const loadStudent = async () => {
    const data = await getStudentById(id);
    setStudent(data);
  };

  const validate = () => {
    let inputErrors = {};

    if (!student.name.trim()) {
      inputErrors.name = "Name is required";
    } else if (!/^[A-Za-z ]{3,}$/.test(student.name)) {
      inputErrors.name = "Name must be at least 3 characters and contain only alphabets";
    }

    if (!student.email.trim()) {
      inputErrors.email = "Email is required";
    } else if (!/^\S+@\S+\.\S+$/.test(student.email)) {
      inputErrors.email = "Invalid email format";
    }

    if (!student.course) {
      inputErrors.course = "Course is required";
    }

    if (!student.address.trim()) {
      inputErrors.address = "Address is required";
    } else if (!/^[A-Za-z0-9\s,.'-]{10,}$/.test(student.address)) {
      inputErrors.address = "Address must be at least 10 characters";
    }

    if (!student.mobile.trim()) {
      inputErrors.mobile = "Mobile number is required";
    } else if (!/^\d{10}$/.test(student.mobile)) {
      inputErrors.mobile = "Mobile must be 10 digits";
    }

    if (!student.dob) {
      inputErrors.dob = "Date of Birth is required";
    }

    setErrors(inputErrors);
    return Object.keys(inputErrors).length === 0;
  };

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleUpdate = async () => {
    if (validate()) {
      await updateStudent(id, student);
      navigate('/');
    }
  };

  return (
    <div>
      <h2>Edit Student</h2>

      <div className="mb-3">
        <input
          type="text"
          name="name"
          placeholder="Enter Name"
          className="form-control"
          value={student.name}
          onChange={handleChange}
        />
        {errors.name && <small className="text-danger">{errors.name}</small>}
      </div>

      <div className="mb-3">
        <input
          type="email"
          name="email"
          placeholder="Enter Email"
          className="form-control"
          value={student.email}
          onChange={handleChange}
        />
        {errors.email && <small className="text-danger">{errors.email}</small>}
      </div>

      <div className="mb-3">
        <select
          name="course"
          className="form-control"
          value={student.course}
          onChange={handleChange}
        >
          <option value="">Select Course</option>
          <option value="Computer Science">Computer Science</option>
          <option value="Information Technology">Information Technology</option>
          <option value="Electronics">Electronics</option>
        </select>
        {errors.course && <small className="text-danger">{errors.course}</small>}
      </div>

      <div className="mb-3">
        <textarea
          name="address"
          placeholder="Enter Address"
          className="form-control"
          value={student.address}
          onChange={handleChange}
        />
        {errors.address && <small className="text-danger">{errors.address}</small>}
      </div>

      <div className="mb-3">
        <input
          type="text"
          name="mobile"
          placeholder="Enter Mobile Number"
          className="form-control"
          value={student.mobile}
          onChange={handleChange}
        />
        {errors.mobile && <small className="text-danger">{errors.mobile}</small>}
      </div>

      <div className="mb-3">
        <input
          type="date"
          name="dob"
          className="form-control"
          value={student.dob}
          onChange={handleChange}
        />
        {errors.dob && <small className="text-danger">{errors.dob}</small>}
      </div>

      <button onClick={handleUpdate} className="btn btn-primary">Update</button>
    </div>
  );
}

export default EditStudent;
