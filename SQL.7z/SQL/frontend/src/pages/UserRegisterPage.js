import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const UserRegisterPage = () => {
  const { authToken } = useContext(AuthContext);
  const [username, setUsername] = useState('');
  const [useremail, setUseremail] = useState('');
  const [description, setDescription] = useState('');
  const [age, setAge] = useState('');
  const [departments, setDepartments] = useState([]);
  const [deptid, setDeptid] = useState('');

  useEffect(() => {
    if (!authToken) return;

    const fetchDepartments = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/departments/getalldept', {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setDepartments(response.data);
      } catch (error) {
        alert('Error fetching departments');
      }
    };

    fetchDepartments();
  }, [authToken]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        'http://localhost:5000/api/users/userregister',
        { username, useremail, deptid, description, age },
        { headers: { Authorization: `Bearer ${authToken}` } }
      );
      alert('User registered successfully');
    } catch (error) {
      alert('Error: ' + error.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto mt-10 p-4 border">
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        className="mb-4 p-2 border"
      />
      <input
        type="email"
        placeholder="User Email"
        value={useremail}
        onChange={(e) => setUseremail(e.target.value)}
        className="mb-4 p-2 border"
      />
      <select
        value={deptid}
        onChange={(e) => setDeptid(e.target.value)}
        className="mb-4 p-2 border"
      >
        <option value="">Select Department</option>
        {departments.map((dept) => (
          <option key={dept.deptid} value={dept.deptid}>
            {dept.name}
          </option>
        ))}
      </select>
      <input
        type="text"
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="mb-4 p-2 border"
      />
      <input
        type="number"
        placeholder="Age"
        value={age}
        onChange={(e) => setAge(e.target.value)}
        className="mb-4 p-2 border"
      />
      <button type="submit" className="bg-blue-500 text-white p-2">Register</button>
    </form>
  );
};

export default UserRegisterPage;
