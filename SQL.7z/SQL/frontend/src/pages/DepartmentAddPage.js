import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const DepartmentAddPage = () => {
  const { authToken } = useContext(AuthContext);
  const [name, setName] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        'http://localhost:5000/api/departments/register',
        { name },
        { headers: { Authorization: `Bearer ${authToken}` } }
      );
      alert('Department added successfully');
    } catch (error) {
      alert('Error: ' + error.response?.data?.message || 'Adding department failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto mt-10 p-4 border">
      <input
        type="text"
        placeholder="Department Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="mb-4 p-2 border"
      />
      <button type="submit" className="bg-blue-500 text-white p-2">Add Department</button>
    </form>
  );
};

export default DepartmentAddPage;
