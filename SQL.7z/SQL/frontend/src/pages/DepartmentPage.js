import React from 'react'

const DepartmentPage = () => {
  return (
    <div>DepartmentPage</div>
  )
}

export default DepartmentPage