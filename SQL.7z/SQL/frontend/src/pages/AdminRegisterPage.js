import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // Change here
import axios from 'axios';

const AdminRegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();  // Change here

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      alert("Passwords don't match");
      return;
    }

    try {
      await axios.post('http://localhost:5000/api/admin/register', { email, password, confirmpassword: confirmPassword });
      alert('Admin registered successfully');
      navigate('/admin/login');  // Change here
    } catch (error) {
      alert('Error: ' + error.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto mt-10 p-4 border">
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="mb-4 p-2 border"
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="mb-4 p-2 border"
      />
      <input
        type="password"
        placeholder="Confirm Password"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
        className="mb-4 p-2 border"
      />
      <button type="submit" className="bg-blue-500 text-white p-2">Register</button>
    </form>
  );
};

export default AdminRegisterPage;
