import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const UserPage = () => {
  const { authToken } = useContext(AuthContext);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    if (!authToken) return; // If no token, don't fetch data

    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/users', {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setUsers(response.data);
      } catch (error) {
        alert('Error: ' + error.response?.data?.message || 'Failed to fetch users');
      }
    };

    fetchUsers();
  }, [authToken]);

  return (
    <div>
      <h1>User Management</h1>
      <ul>
        {users.map((user) => (
          <li key={user.userid}>{user.username}</li>
        ))}
      </ul>
    </div>
  );
};

export default UserPage;
