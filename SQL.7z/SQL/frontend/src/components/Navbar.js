import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar = () => {
  const { authToken, logout } = useContext(AuthContext);

  return (
    <nav className="bg-blue-500 p-4">
      <ul className="flex space-x-4 text-white">
        <li><Link to="/admin/login">Admin Login</Link></li>
        <li><Link to="/user">User Management</Link></li>
        <li><Link to="/department">Department Management</Link></li>
        {authToken && <li><button onClick={logout}>Logout</button></li>}
      </ul>
    </nav>
  );
};

export default Navbar;
