import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';  // Change here
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const AdminLogin = () => {
  const { login } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();  // Change here

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/admin/login', { email, password });
      login(response.data.token);
      navigate('/user');  // Change here
    } catch (error) {
      alert('Error: ' + error.response?.data?.message || 'Login failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto mt-10 p-4 border">
      <input 
        type="email" 
        placeholder="Email" 
        value={email} 
        onChange={(e) => setEmail(e.target.value)} 
        className="mb-4 p-2 border"
      />
      <input 
        type="password" 
        placeholder="Password" 
        value={password} 
        onChange={(e) => setPassword(e.target.value)} 
        className="mb-4 p-2 border"
      />
      <button type="submit" className="bg-blue-500 text-white p-2">Login</button>
    </form>
  );
};

export default AdminLogin;
