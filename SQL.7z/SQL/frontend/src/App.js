import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import AdminRegisterPage from './pages/AdminRegisterPage';
import UserRegisterPage from './pages/UserRegisterPage';
import DepartmentAddPage from './pages/DepartmentAddPage';
import AdminLogin from './components/AdminLogin';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/admin/register" element={<AdminRegisterPage />} />  {/* Change here */}
          <Route path="/user/register" element={<UserRegisterPage />} />    {/* Change here */}
          <Route path="/department/add" element={<DepartmentAddPage />} />  {/* Change here */}
          <Route path="/admin/login" element={<AdminLogin />} />            {/* Change here */}
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
  