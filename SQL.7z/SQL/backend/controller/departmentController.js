const db = require('../db');

// Create department
const createDepartment = (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ message: 'Department name required' });

  db.query('INSERT INTO departments (name) VALUES (?)', [name], (err, result) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    res.status(201).json({ message: 'Department created', deptid: result.insertId });
  });
};

// Get all departments
const getDepartments = (req, res) => {
  db.query('SELECT * FROM departments', (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    res.json(rows);
  });
};

// Get one department
const getDepartmentById = (req, res) => {
  const { id } = req.params;
  db.query('SELECT * FROM departments WHERE deptid = ?', [id], (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    if (rows.length === 0) return res.status(404).json({ message: 'Department not found' });
    res.json(rows[0]);
  });
};

// Update department
const updateDepartment = (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  if (!name) return res.status(400).json({ message: 'Department name required' });

  db.query('UPDATE departments SET name = ? WHERE deptid = ?', [name, id], (err, result) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Department not found' });
    res.json({ message: 'Department updated' });
  });
};

// Delete department
const deleteDepartment = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM departments WHERE deptid = ?', [id], (err, result) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Department not found' });
    res.json({ message: 'Department deleted' });
  });
};

module.exports = {
  createDepartment,
  getDepartments,
  getDepartmentById,
  updateDepartment,
  deleteDepartment,
};
