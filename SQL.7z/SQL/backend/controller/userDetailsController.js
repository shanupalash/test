const db = require('../db');

// Create user
const createUser = (req, res) => {
  const { username, useremail, deptid, description, age } = req.body;

  if (!username || !useremail || !deptid) {
    return res.status(400).json({ message: 'Username, Email & Department are required' });
  }

  db.query(
    'INSERT INTO userdetails (username, useremail, deptid, description, age) VALUES (?, ?, ?, ?, ?)',
    [username, useremail, deptid, description, age],
    (err, result) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(400).json({ message: 'Email already exists' });
        }
        return res.status(500).json({ message: 'DB error', error: err });
      }
      res.status(201).json({ message: 'User created', userid: result.insertId });
    }
  );
};

// Get all users with department names
const getAllUsers = (req, res) => {
  const query = `
    SELECT u.userid, u.username, u.useremail, d.name AS department, u.description, u.age
    FROM userdetails u
    JOIN departments d ON u.deptid = d.deptid
  `;
  db.query(query, (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    res.json(rows);
  });
};

// Get single user by ID
const getUserById = (req, res) => {
  const { id } = req.params;
  const query = `
    SELECT u.userid, u.username, u.useremail, d.name AS department, u.description, u.age
    FROM userdetails u
    JOIN departments d ON u.deptid = d.deptid
    WHERE u.userid = ?
  `;
  db.query(query, [id], (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    if (rows.length === 0) return res.status(404).json({ message: 'User not found' });
    res.json(rows[0]);
  });
};

// Update user
const updateUser = (req, res) => {
  const { id } = req.params;
  const { username, useremail, deptid, description, age } = req.body;

  db.query(
    'UPDATE userdetails SET username = ?, useremail = ?, deptid = ?, description = ?, age = ? WHERE userid = ?',
    [username, useremail, deptid, description, age, id],
    (err, result) => {
      if (err) return res.status(500).json({ message: 'DB error', error: err });
      if (result.affectedRows === 0) return res.status(404).json({ message: 'User not found' });
      res.json({ message: 'User updated successfully' });
    }
  );
};

// Delete user
const deleteUser = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM userdetails WHERE userid = ?', [id], (err, result) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'User not found' });
    res.json({ message: 'User deleted successfully' });
  });
};

module.exports = {
  createUser,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
};
