const db = require('../db');
const { hashPassword, comparePassword, generateToken } = require('../middleware/auth');

// Register admin
const registerAdmin = async (req, res) => {
  const { email, password, confirmpassword } = req.body;

  if (!email || !password || !confirmpassword) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  if (password !== confirmpassword) {
    return res.status(400).json({ message: 'Passwords do not match' });
  }

  db.query('SELECT * FROM admins WHERE email = ?', [email], async (err, result) => {
    if (err) return res.status(500).json({ message: 'Database error', error: err });

    if (result.length > 0) {
      return res.status(400).json({ message: 'Email already exists' });
    }

    const hashed = await hashPassword(password);

    db.query(
      'INSERT INTO admins (email, password, confirmpassword) VALUES (?, ?, ?)',
      [email, hashed, hashed],
      (err) => {
        if (err) return res.status(500).json({ message: 'Error registering admin', error: err });
        res.status(201).json({ message: 'Admin registered successfully' });
      }
    );
  });
};

// Login admin
const loginAdmin = (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password required' });
  }

  db.query('SELECT * FROM admins WHERE email = ?', [email], async (err, result) => {
    if (err) return res.status(500).json({ message: 'Database error', error: err });

    if (result.length === 0) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const admin = result[0];
    const isMatch = await comparePassword(password, admin.password);

    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = generateToken(admin.id, admin.email);

    res.json({ message: 'Login successful', token });
  });
};

module.exports = { registerAdmin, loginAdmin };
