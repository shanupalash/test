const express = require('express');
const router = express.Router();
const {
  createUser,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
} = require('../controller/userDetailsController');

const protect = require('../middleware/authMiddleware');

router.use(protect); // protect all routes below

router.post('/userregister', createUser);
router.get('/getallusers', getAllUsers);
router.get('/getuserby/:id', getUserById);
router.put('/updateuser/:id', updateUser);
router.delete('/deleteuser/:id', deleteUser);

module.exports = router;
