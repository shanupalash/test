const express = require('express');
const router = express.Router();
const {
  createDepartment,
  getDepartments,
  getDepartmentById,
  updateDepartment,
  deleteDepartment,
} = require('../controller/departmentController');
const protect = require('../middleware/authMiddleware');

// All routes protected
router.use(protect);

router.post('/register', createDepartment);
router.get('/getalldept', getDepartments);
router.get('/getby/:id', getDepartmentById);
router.put('/updatedept/:id', updateDepartment);
router.delete('/deletedept/:id', deleteDepartment);

module.exports = router;
