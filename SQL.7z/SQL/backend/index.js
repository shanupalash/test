require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const adminRoutes = require('./routes/adminRoutes');
const protect = require('./middleware/authMiddleware');
const departmentRoutes = require('./routes/departmentRoutes');
const userDetailsRoutes = require('./routes/userRoutes');

const app = express();
var cors =require("cors");
const PORT = 5000;

app.use(
  cors({  
    origin: "*",
  })
);

app.use(bodyParser.json());

// Admin routes
app.use('/api/admin', adminRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/users', userDetailsRoutes);

// Example protected route
app.get('/api/protected', protect, (req, res) => {
  res.json({ message: 'You are authenticated', admin: req.admin });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
