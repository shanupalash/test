import logo from "./logo.svg";
import Navbar from "./components/Navbar";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import LoginForm from "./components/Login";
import RegistrationForm from "./components/RegistrationForm";
import About from "./components/About";

function App() {


  return (
    <div>
      <h1 className="">
        <Navbar />
      </h1>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/registration" element={<RegistrationForm />} />
        <Route path="/about" element={<About/>}/>
      </Routes>
    </div>
  );
}

export default App;
