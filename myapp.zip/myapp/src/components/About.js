import React from 'react';

const About = () => {
  return (
    <section className="bg-gray-50 py-16 px-4 sm:px-6 lg:px-8 h-screen z-10 overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center">
        {/* Text Content */}
        <div className="md:w-1/2 md:pr-12">
          <h2 className="text-3xl font-extrabold text-gray-900 mb-4">
            About Our Platform
          </h2>
          <p className="text-gray-700 mb-6">
            At EduPlatform, we are committed to providing accessible and high-quality education to learners worldwide. Our courses are designed by industry experts to ensure you gain practical skills that are in demand.
          </p>
          <ul className="list-disc list-inside text-gray-700 space-y-2">
            <li>Expert-led courses across various disciplines</li>
            <li>Flexible learning schedules to suit your lifestyle</li>
            <li>Community support and networking opportunities</li>
            <li>Recognized certifications upon course completion</li>
          </ul>
        </div>

        {/* Image */}
        <div className="md:w-1/2 mt-10 md:mt-0">
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSe9XSV9p1fhn2uHV29kExB3_6u9p5HWAkUQw&s"
            alt="Students learning online"
            className="rounded-lg shadow-md w-full h-auto"
          />
        </div>
      </div>
    </section>
  );
};

export default About;
