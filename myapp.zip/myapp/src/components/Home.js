import React from 'react';

const Home = () => {
  return (
    <div className="bg-white text-gray-800">
      {/* Hero Section */}
      <section className="bg-blue-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Empower Your Learning Journey
          </h1>
          <p className="text-lg md:text-xl mb-6">
            Join thousands of learners worldwide and enhance your skills with our expert-led courses.
          </p>
          <button className="bg-white text-blue-600 font-semibold py-2 px-6 rounded hover:bg-gray-100 transition duration-300">
            Get Started
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded shadow hover:shadow-lg transition duration-300">
              <img
                src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhIVFhUXFhgVFRcVFxcXFhYXFRUWGBUXFxcYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICYtLS0tLS0tLy8tLS0tLS0tLS0tLy0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKIBNwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAIDBAYBBwj/xABEEAABAwIEAwUECAUBBwUBAAABAAIDBBEFEiExBkFREyJhcYEykaGxBxQjQlLB0fAzYnKC4ZIVQ3ODorLxJFNUw9IX/8QAGQEAAwEBAQAAAAAAAAAAAAAAAgMEAQAF/8QALhEAAgIBAwIEBQQDAQAAAAAAAAECEQMSITEEQRMiUWEycYGRoRSx0fAjUsEF/9oADAMBAAIRAxEAPwD1F85jlDXO0dtfqiYKwjMVZJK2R8oOX2QDoFp6XGo3mwcCUCyRYyWKS7BUlIFNuuApgszP0kVpjopcpsXDL79F4RFGIWX5u1uvYPpUm+xDepXj+Is+zA6aJOq50UxjULBhqCSeisQTFNpMGlcRZpsVtuHeDiSDKNOYRTnFGQxyYW+jfiOdn2Truj5X+74DwXrNJVB7brI4dh0ULbNACuCSUexYhKjmdhzwqjP8cU0rJu0aC4O6cijn0fslaxxeCAdgVyprJLd9l0oeIQwDuEeiXHTGeoOWqWPQbLtEu0QvDa/tBdXgVZGSkrRFKNOmWGyJ2cKrdIuWg0TyOCru3THu1C6TqssKh5XLrl0iVxwPq8UYx1nEBZ/i3EGvaxjHAvzBwA8DdVuJWsLnFx1Co4BTtN5HDXlfopZ5ZbpD4YrVhGfEZ3kMaOWp5ILxxK6OhkJks7KUbdVZXXuAOaH4thMVW0B+rb3I5FJhJ2nIocahpRT+hPC3xUrpHi3aOzAeFgB8l6UPNAcPnZCwMaLACyuRYo0myrWRMleNoKKo8EytVhjrjdBsXrHRuBbusySSVs7HFydIOuhvuqmIuayN1jqQu0jC9gc92/RWI6ZnS/mj16tkBp0vcyuEyyxk5GEkq1VV9QCAbNvtZaZrANgEAxu7p2NCQ8coRqyiOSM53RSaHudZ8h8UTiwiKwJufNPpYQ12VzbnqiMkV7AbJsMcd3VgZcnCWxRm7GIbDwTKLEg8Os21lcmpWO00JVKSn7GF/U3TJal8hcdLW92VMDFzI48yiDWtA0sqGCD7InqUVp2tA5KbDwOzPzEsUotoknxyDkknk54vLg6I8LQGOcamxWikpWnkoG0oa9rgpmi3Ub2F3dC6XJlM0ZB5KUQ3Vq4IHyed8djOdeS89koDMXNj9oC9jpdfRL6KMixaD5hZ+q4VgMvaBgB8FO8MrtMqjmjWlo894Q/h5XN1boVp2S2SmwUwyOyi7Tr5IFjVNK7SO9z42sppJ6t9iyFNbbh2SrDQXE7KDh7GnSueQCANB0QzAqV7O7K7Nfe6NwtDJGRsAs87jksi6ex04prct1FTYXeVUmrGuLe7axR3FcEGS7bkjWyzs8JJ2sEXUSlB0b0mPHkVmjweQG9kXa5BcIjtYBF2sVeHeJ52elMkJXLppcOoXWi+xTLFEcjtQnOKryRyZuVlFjWIx0sTppnWa0epPIAcygT5Ca4L4cs5j3FkdPcO+C85xv6U5ZA5sMZiGwLva/wsjFxM5wLJwXEn2ifzWS1NbBwjFPzG1dxhFJOGhpJkeBr4my0mP0sjGgxmwtyXlOD5HzxFgN+1bof6gveK+DNGNL91K8Mc51XoePYjJMSbvK3vCoP1dt+izuM0MjX95lgditRw+20TR4IMkXHZjVJSVoIOCqVU7GDM9waBuTomY9ijKeMyPI6NBNi49AvM6vEp62UZb72DRqG+gNj5oYw1b9gXKtj0qbjuBjcsDXzybAAFrfVxF/cFmcQx+tkJLwxh3DQBcDyJJsgdVi7aNpjj70trPk3seYba/vWd/wBoOe4uzne/Mi/5fBP0uS9haqLPRqH6RKqJobLFHKBppeN1vPUfBamn+kuhLRcyNda7mFhu22+o0d6XXlOGYw24ZUND4zpcEXB5EEc/BR8U0kTMpjLiCRkJ+8C6yKLpgSgmrPdsI4jgqDaKQE63bs4W0vlOtvHZVSS6qNuQXjXDmIupp45QASy5sdAQW5XAnloTqvRsExn61mnhdlJNnNdu0/mOhQznum/U3Hjq69DTGF5cdfVST1ojAZe7rboM5sp3nt5ABVX4fGTmfK5x65v0S/EjG9CdsYoW1rqgtCGi7nyBvmVFjuMRuj7ON4cTvbVDm0FNfYuPjc/NXqemiHsx/BC5ypqK5DlTkpSfHsEMKZaFt0SiDbKtCBltsFYjsnY1pVE2R27LDLJLmfokmiQI6jBGhQzEoQ0ixRRuHaWEh+Cqy4A7cyE+dl58cWVSSXCLm8fxatw9hrrxt8lcYh+E6R26aK61y9OPwogl8TJnFMebp11DK8DVaaUntzPPlZYnFKoRzOjdod2nkQtuZrXIF1muIcI+tC5GV49khIzQ1IpwT0y34MzK95cSCCPPVG+GYnGZpdyQDDuFJw77STKAeR3XoGDNZGMvPqeanx4nq3Kc2ZaWkHo0OxmlbluALqaeqtohmLzExnXW4VeRJxaZDicoyTRJhbLOt4KlxpxIKSMW9t+jfDqVPg+j7Xvosv8ASPRiWeFpOmU6eoS4vTjDa1ZNwRhGMPmkuXOJO9yVTqOKJ6WozNeS3NqwnQi/wR/BsIih1CqY5gEcxvsVOpq7Knj2o9DwjG4p6cTtPdtd1+VtwV4v9I3E0tXIGsOWNju43e5/E7lfwVqqxL6rSz07Xm7rW6a+0vPvrhOjhpyJ5HqqYyclZK4KLHVMkgvnAJtqmXa5ua2vQJRObbV177Lgc25BO3T5IzC9w3N2dRE52wkafS9l9IyPswHwXy/ms8EHxC+kqDEon00TnPAzMadfJBO+xyB+JubNofuhUTUCCB0h2Y0ut1siVRW0rb3maL+IWN+kHEmspmsjNxI7fq1tj8y33KOOPJr8zsqc4aNjF4zistTLq4m50AtbyA5BaCoayhpQP988d42F2tI2ubgIZwTTd907/YjF9r3d90e9BeJsXM0rnEkm/QA++1/irKt0hCdK2DZ6gucXH4n89lNDNm0y38QflrdU4r+A+J94/VF6OIu0Jcf6j8h+qN0gI2yqQb2A+d/iUWw+R7sjHxiVjX5wCSNeYzNsbfopWxRtGp26DS/ltf3+ia7Ewy9t7e7p63t7iluV8DFGuQbimIXlka0ZGh2gNySOtz939lF+BsQy1DWONhJ3N+Z9n4296x88xuCfvAelv83U1NUFha4btII9Nv0RuNoWpbn0RHhbrbKWPCyrvCWICppYpgfab3vBw0PxRgU4QLGjnkYCiwogq22iRPswnBgWqCBc2QwwCynawJxTmuCOgGxlx0SUgkCS0wz9DJsi0ou30WTwvFMxcLbOI92yNOxRrR33BviSAsjki1yE4Pkkwc6OHiUQLrboLhdY3vuzDLvfkvO+OfpCLi6GnNhs5/6JmFalsBldPc9jppQ5t2kEeCUrPBeZ/QhjRkZPA91y1we2/R2/xB969TyrZKnR0XasGO2It5KFjNQrlezmoYWoQ09inU04B81G2MK7VNVY6IWg09io6XvW5BcrDduuydTMJcSRzUOMODrRg2N0qe0WMgrkkiB1Z2LDJ0Giw+C4k6qqXukN3A6eAO1lpeJxlp3C/JeV8NSvdVtDSQc2viPFJSck0OTUXZ6WIqgS5bAsPPolJDUdqG6ZAdVdmxLKLa5h0TYMXbu8211JFkkf2syHHeDBuQ5u9JfTpbms0eFpQ3KRvzGt+i2/0tQOe2nmi1YLgkcrgWKq4Bi5fCzO0k+yCAdx1VEnKC2EQ0zfmMg3gqcWykG+9+SgxThOaIZrF/UtB0W7rMRex4Hs32AaXE+7ZanDI3Oju9trjY/mEPjTQcsMK2PI+BsNidK587Q5rQA0O9nMevWy9Ykw1pgaAAABYW2tyVWmwuGG4DRZzy432v8AotKwMMYyEEeGy5Nzk32F5NMIJdzy7FaMtJ0VvFcHNQyBo+634uP+ERxyN5JDYyUbwqD7JpIsbW15LJSrg6FS2Zm58IfTUwbE3MSbvt+9t1i8Twid5v2OUeGpXsTGW0VauabGwQxytbjXjT2PEG4O9p1afz+KLU1JJawFh+9zzW0rwSfZ89OaBTyEfEfFH4rkYsKiZrEiWHU68tf3b5oLNLf5n9+9GcUiLzfUoW+icNfnp81RBqiXInZTe246bqZp06/vVRTNta/zCkpwDoNDuAfjY/8AhNFdz2P6DMZBZLSvOoPaM8QbAj5fFethoXyxwzjT6Oojmb907dWn2gvpvA8XiqYmyxEFrh6g9Cg4dHSXcuFoXA0XT10OC0ATXBJ1lxxC7mC44aLdF1dzhJcceXtxL7LuNLSR3tDueYKE43SnshKO0f8AzOa6w9+y1P1+Y/7x3ub+ipYnUydm7uyS3+60F3wC86Gm6Vno4sfhPVKqRhsS4mc2n7JjiHHQ/msf9UlkaXsjc5o3LReyK4thlU55P1Se3/Bk/wDyjX0dVE9POY5aeYRv/FE8NDupJbovYX+LF5Tzp1mzO+OxV+irE3U1c2RzJOyc0xvIa4tF7FpJtoLj4r6NjqQ4AtNwdbrLNjbb2AAfBW+HK4BxhOltW+SlXUa5bjn0+iNp2HJ47grPVWItgJ7WRrQPxEBaoWQfHZIRZssbJL8nNDh8Qjm1FWxcE26QLocZZUAviOZjTbMNiRvbqnSVV7Ac0xpZGLRxNjYfuts0egCLYc2J4uzl13S4ZNTY6cNCTK0cRDdCVTrKbQvDSXDZaCaMAXsoI6sfhWzcXswIOXKMri+GPfTudILDLe3Neb8O4JLJWNdGA3S5I3svYeIXSSROjiF3O0t4FC+C+F5KZ0jngXcRbW5AA2SUvN5R2ry+Yz0OCzvqJGMvcC+Z2x8FZpOG5HTNZIcxOrrbNC372WLdt9fcVHBJFHcg3JNydytUIp2zHlk1SO0+DQtYGFocB+LX5oXiWERRNJjY1ovmLQLDxICMVFaALhZ/GJHPFmnfc/NU+DrW5NHK4u0A5qmIOBIBA6q1JijSLt2QWSRrXtj7MvJtawuRc6E9FeqsBqZBZrRG37znakN5kNBF9PEKOWCUXR6KzwlGyWnjM5/kvYn5hajD6RjYwwNDWjQAaKszC2UbS1v8IDML3JzEm41JJ9TzVzDqMn7R9y53InRo5ABX4sUYxPOy5XOQOqKLK/e99lVEgBtyOl+h5X89VpamMEd6yA1OGy2dkby0LtvXwUebpoweqK5HYctvcrS6Ku+QqChkmu9krRYC7XC58wb+lvVUK/ECDYOYNbd4HntzUtHoxLr4wdwhGJ4Rm1Dbq3DVSD2uyI83D8kVppA4aW9NfisNZhKrBwBcgjxWZlwV8j8rdTe1l61j0A7IkDbVZaioXGLu6Ped9rA2NyeWhTY5GkLeNSKFNwnSRxXmidK/Zzszmhv9IBtosTV0bWyyRsOsb3NHiAbXHLzHVbzGK5tFE7O8PkfYRxjTMRsbH7t7XP5rzWOZ/aEv9ouuSep1N07BrdtsT1GhUkiaRqO8HcXz4fJdpLoz7TDsR+vihLwOezhp5j81AwG/Ijx3CfyTM+qMBxllXAyaL2XDnuDzB8QiIWE+hyAsobn7z3EC97AG2/ndb0FYmLkqZwLp8kk6y2zKG3XE2XRdQ2dRgGQlGeH6hsLnGQEAgWNuisx4M778h8mNDR7zc/FOmhpYdZCwHlnOZx8gbn3LI4ccXasonmlNUy8MfgPsh7v6WE/JZqu46k7fs4KGWRgNnSWAb42udbIsMQLtIYXkfieOzZ7jqfcrjG2YAQLjXuDQE7rcl15RcIxT3M5xZW1MoZ9VAbzOfb1VbCKGqzB8uQuHNtwCtXJQtk9phUTIywgNPdA2Kg1zb3i17lKcVGos6zEHsFnNJN+XJCsfxMOt3srgNrIzLOBuqcz2OvcAjna1x6prnKXlbOhGKeqjJnFsot7R/E79FqeGpvsS7S55E2KpSYHC9x+zcOhJ0TPqTw8MDbMA9oH4IYXCXFjJ6ciq6Lk+LOaLygjoBqECPGDQ5zHAi2oJBsfBaJsDVYpYIx7UbXeYCZTb5FqcYrgy+FcVQvnyOe5ptdrspyX6E2stfS4qHtuL+6ymfJGGkNY0GxtoN1manFe6QwjOHAAHlqL6e9FJ+GqTMS8Z3VB5rdSTvY28ys7mkYSHNIHWyJ0lbp7WbqT+Sm+sApLaaGRTizO1WMHKQ0F1vwi6kFSTTMNiHSW30IBPRHGOaNQAPJPL28wFVj6vTGmifJ0+qVojwqga07DU3J8hoiFU4WLRzBBPmFDTd92Vv/gIzHTtA2HmdSjWWU90hUoKGzYJrx2kUT7X2uPMX+YT4RKdm2HjoPiicTcunK+nlyHpt6KS6JqT7gpxXYpikJHeI8bKy9otbwt8F1zlDI9E7AMxWU5bmB0/NZytw5kndcN9B4rcV8QeLHfkVjqyoDX5X5gWnQZHEeYLQbrz8uNxfsepgya17gql4QYHhxJIGwOoG36LSwQhosAuUtW2Qd0m43BaWn3OAUjkDtjPYqYiMzcvLmvPOIeIZYnGKDJfK0Xc3MQbbi5tfXmCtlxDigiaQLZyNB08SvNIqJ9TOGMGZ7nZW+LjuT4AXN+iLHFXuDJtR2LHBnD7qiSWqqbvDTlu/XO62u/IaKhxFg2V5MbDl121t+i9opcB7CNkDTdoAzHmXW1v4FNqcEja2xAcSdBbclU3K7JfLVHgkFO83ZY33YfEcj+/ySdRyHXIQedxYj38l9AUXAUGjpRbnbQknqf0CODh+n9nsWub0e0W8xdGnIW3Ayf0Z4tGylZCS7M299HHQm97rewVDXC4IKzGNcFNymSjBilGoa1xyPtysT3T5G3zGf4ex+Tt2xz5WnMWZtWkPF+6+50OmxHVLuUXTN0xnuj08LqbDqAeqfZNEHCEl1JccZx1Lm/i1Mr/AOVn2bfcwA28yrFJRRM1iha083HVx8zufUp9VOA4E23ta2g81DXYq1vs69ctvippdUrpASzKJcc7rr8vcFx1VbmFmK/iNjR7dh45T8iqVNxNA5oJl1uR016X5cj43QS6ppWF0cpdRl0Je5tIJ3vNs3mpal0VrF2o/Dq73BY9nEkbdnNt6Kkzihs0gZGXE3GbLyHO6GHWWvhs9bJ/58ub0oN1EUjibOIb/NYH5odR4E2N5eHkuJudXO+Gy0UMDbXEZ/uI/wAqwGH8LR6kodW+0X9v5EKbSq/2Boc8i2Z3o0D5rjqIvGriPNx+TbImWn+X/Tf81yzvxe4AI08n+r/AuU41W33B8OH5DcOPjYb+pVx8bQLkuaOZ2CsNA5k+/wDRJ0LDoQD4HX4Fd4OSUtUl+/8AygPGgo6VKvqQtA3BJFtFSdQszZuyIPXRFZIiOVvBNyp0o2D5rtSf4ANbRyXvG0X5i9gfHzUccVT/AO20f3/4WhyK5TSMAsW69d0KxJse8zSMsKep5tYP7ifyUgoJ3bFnxK2IAO1k4BM/TL1F/qpegF4foJIy8yEEkACwI89/RGJHhou4gDqTYKCvqxE3NYuP3WjmUIicXHPIc0nJv3WeDR16u39Ebksa0oXplkephsSg7H5rgKHwzZhf9+q52gLjqRY7NNtwOS6OZdznifYvSPtruPDVUTXRnZ4v0Oh9xU/+yo75u8T1zv8AyK5PhEL9XxtdbbNr805ilQJq8SY02JAUOdslrEX2/RFZsCiJBtbqLBwP+oG3oo/9gQg5mtLTcHuuIFxtpslyhKWzGxnGO6BX1MtO1ihXEtLW5S2lDRcd2QAON/I6D3FbYxjW433KjbAR7B05g/vRB4CQf6hnizODsQkuXt13c979D49St1wTww2lBkd3pjcF3JrTyaPEWuVpMQmkYL9kXAb5Tc/6QLrkDJHBpDMgIG/tAdC0gWKxQSYUsrktyy0ANJPQn93UOCxB5Mjt/uA8m3OvmbX9ynqYC4WOw5ctPmrDI7AeVvcm1uIvYshqe1qgY5TByIWPsgPEXCcNUc9zHJa2doHetsHj71vQ+KPArt1zSapmqTTtAnAqaWKPs5spLSQ1zSbObuCQdjqRbwRNPuuFq5KlRzduxqS7lSWmAuowVj9HvkPqP0WT4g4KFy8Pky8yw2cPPTUeK3dPOHi48ipUiWKM1a+43Hn7tJr+/Y8xh+jeKRubtpni2zpnBvk4MsQh03AVDGbSspGk696tkDj6SAkr0isoXxntIP7mcj5D8vchVdhlBOM81JG59u93NbDc3ba4+KSri9LHPGvjxrb8r5mXZwrhrRcQ0r7DlNG/0s46lEMNqqaG2Snyf0tj+ORxUE3A+FTONqUE22jc9tgOgEgsuD6L8O/+LKP+dIP/ALSmKCfqzJZHHaTX3o0LsXicLXc3yuD7ws1jEFa5xNJWxZTs2Zr8w/va6x/0qb/+X4cN2yt8qiT9ULreFsDhdlfUyh41LBUvc639Le8qIwkuLRLklgk/Mr/vyKUlJjgufrFMRt3ZJeemwZ4p0uH4zuOycLN0+su3yjMeXO59URoMFwy4dBS1E3Qvmmyeoc8A+oWjiqmxNu2OGAAfhaXDzcCgyZVD4p1/fYKGGE/hxfjb9gFR0+LmMExU2e57r3PcLcj2jL38rK1HHi7Rd1NQW5/azX9waqtZx1BmyNqnyu/DEA4D+5jbD1KruxaSXWOQNHMvZO425gZ2tF/Uqd5lWyfzdJfkqXTu92vkrk/wjcYNNK5lpo2tffXsrmO1gRlLu8fUDX3m+9iyeGTF8Xdjlza6SsmjzEAG4JAsCqMGKTQSGDOHufmccrpHNhZYhti8nW5Gthf4gm1GNsGEdclGCe/rX8s3FrbrhcLXv6IdR4nGzsYpZQJZG3aHE3d01PM7C+9kX9PVT5ZTS1R+wEoS1bMhbIRtop2Vx5/v1UU0hta3vQmvxMMNmjMeeoFtv36IodRUdUthscDyPTFWGK+sGTbW4tz93uQQzH2gdtxbX3fko4K7tmvaBYttf11HyUNVUPy96N2cDQtF7+7cedlk8nieZDoYnjbhLkmmxFzLva3MCLuA/wC4KSkqJDYhnfkO2m1tL+ix8tdVOcA2jkYw3z5nM1J/CGki2+5C2vDR6ixG2b2teQB8uXVbCDk6bNySjCN0aWBpDQDuAAU9caoaupDBrvyCvbUVueak5PYklkA3PpzVV9T0HvQ2eqsczzZKnrQ8XYC4deXoTuppZ23SKY4KVsvF5PMqN8gOj2hw+K4xzudh5JELFOXKZrghtLQND88csm1iwyPLf9DjYHxCI3tufeh2RU8Sw5s4IlBe0ixY8lzPVhOW/jZM8bbdAPFb5D5AI0UD3W32PwKBUmH9l/Cc5g6BxLR4BjrtHoFYllqOT2H+pn6ELvGRngvsW5p8t06nrbrOSUdc99hNTsb/ADRSO9NJBbzRnC+H5GG8s4d/KxuUe9xJWxk5cGyjGK3C7HqYJgpQOZT+z8U0Qx2ZK642OydZaYK6SVklxxXpIcrbaeNlPZBJMWmIuyA25F3PyvZQH63Ju4MHnr/0qOXV44bK/sUw6OSW7S+v8Gge8DcgeZssvxFV0w1zDX2rbHy8U+Th4vHfqJAerMo9O8HKzh/D0ERzBmZ/J7yXuB/lzaN/tsihKXUL0/cLXi6d3bk/bZfW/wCAJgOFGJjnxTSgyAH7dzpA0C9g0OItud/BNxGned66ceEYiaPf2Zd7ijVVhEkjiXT2byAbqB5k2+CCYhT0TPbkllcOTX6epbZqzJPPGPKS93v+A8GHp8ktk2/SMdl96AdTgdHI4NlfPKTykqZnA9e7mA9LIlhnDNNHYw0kLCNQ7IC4ertR70Ll4gbCCKeCMEnkLkeJtb3lV2R19YLtzFp56iPXfYWd6XUKlPJzJs9V9JDGraUV6s09ZXwx/wASYX/C3vHys3b1WdxDiiO+WOLMeWfUnyYz9SiWH8Btv/6iRzv5W9xvv3PwWow/BYYB9lG1vWw1Pmdz6pkcD9KFS6jBDi5P7IwVNQV9RswQsP4/sxb/AIbNT/dbzR/DODGs1mlfKdNB3GafyjU+RJB6LV5bKpimINhYXuNk6OCPfcmydflkqjsvYocQYoIWZGavd3WgbknYIG3DuzMcZOaaZ95XeAGZ1vAd0DzKu4FSukcauYa69m0/db18yp8JYZKmSXcMHZt8ycz7fAei2buog4VpUp+i/LM7x+biW5LQA1pc0Xc1vYTElviN/Nb/AAlx7GMOcXOyNDnHdxDRdx8TusnidjVgHnI3Q+ERH5rYRNsE19iV8ErmoLiWFQd6R4tzJu7y5FGQ9RVlKyVpa8XB8SNttkvJBSjwn8xmHI8c07aXeuaMnDi/Z92Ng7MbB983ib30V2nxxj3BhbYk2FjceugRGLAIG/cv/USfhsrJpQB3QB4AAKaGLMuX9C7N1HTS4i79br697KrgpI3jmpew6qtz12T+CK7CEVSRsSfBBcVxMA5373ytbbW+wAHM+HiiTYehUFTTA2JAuNjYXB6g8ls9TVHY3GLsCfU3PIfVHu7iIbf8w8/6dvNVcT42hgdl1d4MbfLbry9FZr8Glf8A7646FtvkUKk4Rze0G+aUkUuUWRs+kmEmxD2jq4fpdaHCuIGTNDmvBB6H92KylR9H7XbOAQ6HgCqgf2lNLldzB1a7wcOYR0uzAtHqjKsdVLHUgrEUBrm6SQNPjG8EednWI8tVbkr52OF6eUt5loa63oDf3BBqZzxx9TYghKyzUGPx3sXZT0ddp9zrFE4sQB5olNAPG0Ei0IhQVOYZSe834jkUFbVDqoJ6ktIe02cP3Y+CZHJpdgSxalRq0lVw2tErA4aHYjoVaVidq0RNNOmJJJcWmHUlxJccD+01udT+9lztSmJJUcMF2LdKLTTcJyrwvtop1LJPHLYTOPZmVx+irJXuDCCy/du6zbeI5lDYOCpnfxZ2AdGNJPvcQPgt4kWpmLHiyO5q5e7GS6/qMcVHG0l7JGfw3hGmiscnaO6yaj/T7PwR0Cyckr4xjFVFUebkyzyvVNtv3OWXMgTklzSfIKk1wyrXObGx8jjo1pcfJousVhjH4i9szmubADcA/fI+YW8mhDmlrgCDoQdiPELsUQaAGgADQAaAJbxRY2HUSiB8Yo3OheyPuuIsLaKDAMMNPC1hdmdu5x5k7rRJpYOiW8G9pjl1W1NGGr4b1rBY3Ls5IB2DQ35rWRHRWHUjCb216pGmHIrPCkF48GR2XLKUQHqmHQ2QOLXIUZp8HAV1NISB6oQhPjBVX6tYknXorgSIXNGp0Ve1tunStHVPkhBURHJ3oULCRHlHM+5MuBtdPLC24+Kbl003QhD3Q+C60WXIybbrrdTzIXGDw1p5e5O7JMLeiXaLTjklM06OaD5gEe5UZeH6c7MynrGSz/tIRRr0g8LqRylJcAKbAXD+HO8eDsrvmL/FQQYZUFxa+VlvunKRr0Oq0qTm3Q6EF4siHh2nkiztktY2Isb+e48ka7QIW4PtZrreYuqs0c9tJBfqG/5VEZqKpCJRc3bYezrvahY+alrDtU/9IVB0VWw3dUlw6ZQsedeh3ge56AHjqksCcUkbvc+RSXeOjvAZq0kklQUCCttXElL1PYXkOpzUklPD4kJfA0riSS9c88SSSS44SSSS44S6uJLjTqSSSw4r1ziGOt0KH0Z0C4kp8/KLOm+Fl4JOSSSRwgupJLjhpXOSSSw0jfsoGpJIWGuDnMqen2KSS5HSE/mookklx3YTVJGkkuOZIxOK4kuB7nWqQJJIomMqVZ0QqbZJJKlyHEHThJJJYNP/2Q=="
                alt="Expert Instructors"
                className="w-full h-40 object-cover mb-4 rounded"
              />
              <h3 className="text-xl font-semibold mb-2">Expert Instructors</h3>
              <p>
                Learn from industry experts who are passionate about teaching.
              </p>
            </div>
            <div className="bg-white p-6 rounded shadow hover:shadow-lg transition duration-300">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDGvjdlFv0yha0VI_PUgPrtnlfZETuKRA5ZQ&s"
                alt="Flexible Learning"
                className="w-full h-40 object-cover mb-4 rounded"
              />
              <h3 className="text-xl font-semibold mb-2">Flexible Learning</h3>
              <p>
                Access courses anytime, anywhere, and learn at your own pace.
              </p>
            </div>
            <div className="bg-white p-6 rounded shadow hover:shadow-lg transition duration-300">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3p-49MmDHrls9nIUmbj_Mr0su5HlPC5eoBw&s"
                alt="Certification"
                className="w-full h-40 object-cover mb-4 rounded"
              />
              <h3 className="text-xl font-semibold mb-2">Certification</h3>
              <p>
                Receive recognized certificates upon course completion to showcase your skills.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 bg-blue-600 text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Learning?</h2>
          <p className="mb-6">
            Sign up today and take the first step towards achieving your goals.
          </p>
          <button className="bg-white text-blue-600 font-semibold py-2 px-6 rounded hover:bg-gray-100 transition duration-300">
            Sign Up Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default Home;
