const express = require("express");
const router = express.Router();
const adminUserController = require("../controller/adminController");

router.post("/admin/regestireuser", adminUserController.createUser);
router.get("/admin/getallusers", adminUserController.getAllUsers);
router.get("/admin/getuser/:id", adminUserController.getUserById);
router.put("/admin/updateuser/:id", adminUserController.updateUser);
router.delete("/admin/deleteuser/:id", adminUserController.deleteUser);

module.exports = router;
