import React from "react";
import { Route, Routes } from "react-router-dom"; // Corrected import

import Login from "./pages/Login.jsx";
import Home from "./pages/Home.jsx"; // Create this component for home page
import Register from "./pages/Register.jsx"
import Dashboard from "./pages/Dashboard.jsx"
import Admin from "./pages/CreateUser.jsx"
const App = () => {
  return (
  
      <Routes>
         <Route path="/register" element={<Register />} />
         <Route path="/dashboard" element={<Dashboard/>}/>
         <Route path="/admin" element={<Admin/>}/>
        <Route path="/login" element={<Login />} />
        <Route path="/home" element={<Home />} />
      </Routes>
 
  );
};

export default App;
