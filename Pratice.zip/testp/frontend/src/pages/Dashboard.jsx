import React, { useEffect, useState } from "react";
import axios from "axios";
import UpdateModal from "./UpdateModal";
import ConfirmDelete from "./ConfirmDelete";

const Dashboard = () => {
  const [users, setUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null);
  const [deletingUserId, setDeletingUserId] = useState(null);

  const fetchUsers = async () => {
    const res = await axios.get("http://localhost:5000/api/v1/admin/getallusers");
    setUsers(res.data.data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/api/v1/admin/deleteuser/${id}`);
    setDeletingUserId(null);
    fetchUsers();
  };

  const handleUpdateSubmit = async (updatedData) => {
    await axios.put(`http://localhost:5000/api/v1/admin/updateuser/${editingUser._id}`, updatedData);
    setEditingUser(null);
    fetchUsers();
  };

  return (
    <div className="p-5">
      <h1 className="text-2xl font-bold mb-5">Admin Users</h1>
      <table className="w-full table-auto border border-gray-300">
        <thead className="bg-gray-200">
          <tr>
            <th className="p-3">Name</th>
            <th className="p-3">Email</th>
            <th className="p-3">Profile</th>
            <th className="p-3">Age</th>
            <th className="p-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u._id} className="border-t">
              <td className="p-3">{u.name}</td>
              <td className="p-3">{u.email}</td>
              <td className="p-3">{u.profilename}</td>
              <td className="p-3">{u.age}</td>
              <td className="p-3 space-x-2">
                <button
                  className="bg-yellow-500 text-white px-3 py-1 rounded"
                  onClick={() => setEditingUser(u)}
                >
                  Update
                </button>
                <button
                  className="bg-red-500 text-white px-3 py-1 rounded"
                  onClick={() => setDeletingUserId(u._id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editingUser && (
        <UpdateModal
          user={editingUser}
          onClose={() => setEditingUser(null)}
          onSubmit={handleUpdateSubmit}
        />
      )}

      {deletingUserId && (
        <ConfirmDelete
          onCancel={() => setDeletingUserId(null)}
          onConfirm={() => handleDelete(deletingUserId)}
        />
      )}
    </div>
  );
};

export default Dashboard;
