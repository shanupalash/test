const express = require("express");
const router = express.Router();
const authController = require("../controller/register");
const loginController = require("../controller/login");
const verifyJWT = require("../middlewre/verifyJWT");
const logoutUser=require("../controller/logout.js")

router.post("/register", authController.registerUser);
router.post("/login", loginController.loginUser);

router.post("/logout", verifyJWT, logoutUser);

module.exports = router;
