import React, { useState } from "react";

const UpdateModal = ({ user, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({ ...user });

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    onSubmit(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white p-5 rounded shadow-md w-96">
        <h2 className="text-xl font-bold mb-4">Update User</h2>
        <input
          value={formData.name}
          onChange={(e) => handleChange("name", e.target.value)}
          className="border p-2 mb-2 w-full"
          placeholder="Name"
        />
        <input
          value={formData.email}
          onChange={(e) => handleChange("email", e.target.value)}
          className="border p-2 mb-2 w-full"
          placeholder="Email"
        />
        <input
          value={formData.profilename}
          onChange={(e) => handleChange("profilename", e.target.value)}
          className="border p-2 mb-2 w-full"
          placeholder="Profile Name"
        />
        <input
          value={formData.age}
          onChange={(e) => handleChange("age", e.target.value)}
          className="border p-2 mb-4 w-full"
          placeholder="Age"
          type="number"
        />
        <div className="flex justify-end">
          <button onClick={handleSubmit} className="bg-blue-500 text-white px-4 py-2 rounded mr-2">Update</button>
          <button onClick={onClose} className="bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default UpdateModal;
