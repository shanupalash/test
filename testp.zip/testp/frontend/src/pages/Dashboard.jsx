// src/pages/Dashboard.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import UpdateModal from "../pages/UpdateModal";
import ConfirmDelete from "../pages/ConfirmDelete.jsx";
import ErrorPage from "./ErrorPage.jsx";

const Dashboard = () => {
  const [users, setUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null);
  const [deletingUserId, setDeletingUserId] = useState(null);
  const [unauthorized, setUnauthorized] = useState(false);
  const navigate = useNavigate();

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get(
        "http://localhost:5000/api/v1/admin/getallusers",
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setUsers(res.data.data);
    } catch (err) {
      if (err.response?.status === 401) {
        setUnauthorized(true);
      } else {
        console.error("Error fetching users:", err);
      }
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setUnauthorized(true);
    } else {
      fetchUsers();
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const handleCreate = () => {
    navigate("/admin");
  };

  const handleRegister = () => {
    navigate("/register");
  };

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");
      await axios.delete(
        `http://localhost:5000/api/v1/admin/deleteuser/${id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setDeletingUserId(null);
      fetchUsers();
    } catch (err) {
      if (err.response?.status === 401) setUnauthorized(true);
    }
  };

  const handleUpdateSubmit = async (updatedData) => {
    try {
      const token = localStorage.getItem("token");
      await axios.put(
        `http://localhost:5000/api/v1/admin/updateuser/${editingUser._id}`,
        updatedData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setEditingUser(null);
      fetchUsers();
    } catch (err) {
      if (err.response?.status === 401) setUnauthorized(true);
    }
  };

  if (unauthorized) {
    return <ErrorPage />;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Admin Users</h1>
        <div className="space-x-3">
          <button
            onClick={handleCreate}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm"
          >
            Create User
          </button>
          <button
            onClick={handleRegister}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm"
          >
            Register User
          </button>
          <button
            onClick={handleLogout}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm"
          >
            Logout
          </button>
        </div>
      </div>

      <table className="w-full table-auto border border-gray-300 rounded-md shadow-md">
        <thead className="bg-gray-100 text-left">
          <tr>
            {["Name", "Email", "Profile", "Age", "Actions"].map((h) => (
              <th key={h} className="p-3 font-semibold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u._id} className="border-t hover:bg-gray-50">
              <td className="p-3">{u.name}</td>
              <td className="p-3">{u.email}</td>
              <td className="p-3">{u.profilename}</td>
              <td className="p-3">{u.age}</td>
              <td className="p-3 space-x-2">
                <button
                  className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md text-sm"
                  onClick={() => setEditingUser(u)}
                >
                  Update
                </button>
                <button
                  className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
                  onClick={() => setDeletingUserId(u._id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editingUser && (
        <UpdateModal
          user={editingUser}
          onClose={() => setEditingUser(null)}
          onSubmit={handleUpdateSubmit}
        />
      )}
      {deletingUserId && (
        <ConfirmDelete
          onCancel={() => setDeletingUserId(null)}
          onConfirm={() => handleDelete(deletingUserId)}
        />
      )}
    </div>
  );
};

export default Dashboard;
