// src/pages/CreateUser.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import ErrorPage from "./ErrorPage";

const CreateUser = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    profilename: "",
    age: "",
    description: "",
  });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [unauthorized, setUnauthorized] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setUnauthorized(true);
    }
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      await axios.post(
        "http://localhost:5000/api/v1/admin/regestireuser",
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMessage("User created successfully");
      setFormData({
        name: "",
        email: "",
        profilename: "",
        age: "",
        description: "",
      });
      setTimeout(() => navigate("/dashboard"), 2000);
    } catch (err) {
      if (err.response?.status === 401) {
        setUnauthorized(true);
      } else {
        setError(err.response?.data?.message || "Error creating user");
      }
    }
  };

  if (unauthorized) {
    return <ErrorPage />;
  }

  return (
    <div className="bg-white shadow-md p-6 rounded-lg w-full max-w-md mx-auto mt-6">
      <h2 className="text-xl font-bold mb-4 text-center">Create New User</h2>
      <form onSubmit={handleSubmit}>
        {["name", "email", "profilename", "age", "description"].map((field) => (
          <div key={field} className="mb-4">
            <label className="block text-gray-700 mb-1 capitalize">
              {field}
            </label>
            <input
              type={field === "age" ? "number" : "text"}
              name={field}
              value={formData[field]}
              onChange={handleChange}
              className="w-full border p-2 rounded focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>
        ))}
        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 transition"
        >
          Create User
        </button>
      </form>
      {message && <p className="mt-3 text-green-600 text-center">{message}</p>}
      {error && <p className="mt-3 text-red-600 text-center">{error}</p>}
    </div>
  );
};

export default CreateUser;
